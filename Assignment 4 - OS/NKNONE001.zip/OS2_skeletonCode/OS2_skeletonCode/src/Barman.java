//package barScheduling;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;

import javax.annotation.processing.FilerException;

import java.io.IOException;

//import DrinkOrder.Drink;

import java.util.Comparator;
import java.util.Hashtable;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

/*
 Barman Thread class.
 */

public class Barman extends Thread {
	
	private Hashtable<DrinkOrder.Drink,Integer> drinkServed = new Hashtable<DrinkOrder.Drink,Integer>(); //how many B52 were served?==> Integer
	private CountDownLatch startSignal;
	private BlockingQueue<DrinkOrder> orderQueue;
	long throughPut=0,firstTime,lastTime;


	
	Barman(  CountDownLatch startSignal,int schedAlg) {
		if (schedAlg==0)
			this.orderQueue = new LinkedBlockingQueue<>();
		//FIX below
		else this.orderQueue = new PriorityBlockingQueue<>(); //this just does the same thing 
		
	    this.startSignal=startSignal;
	}
	
	
	public void placeDrinkOrder(DrinkOrder order) throws InterruptedException {
        orderQueue.put(order);
    }
	
	
	public void run() {
		try {
			int total;
			DrinkOrder nextOrder;
			
			startSignal.countDown(); //barman ready
			startSignal.await(); //check latch - don't start until told to do so

			//int temp = Integer.MAX_VALUE;
			Patron pat = null;
			boolean firstDrink = false; //first drink being served for the patron
			firstTime = System.currentTimeMillis();
			while(true) {
				nextOrder=orderQueue.take();
				//orderer = nextOrder.getPatronID();
				pat = nextOrder.getPatron();
				if(drinkServed.containsKey(nextOrder.getDrink())){
					int oldVal = drinkServed.get(nextOrder.getDrink());
					int newVal = 1+oldVal;
					drinkServed.replace(nextOrder.getDrink(),oldVal , newVal);
				}
				else{
					drinkServed.put(nextOrder.getDrink(),1);
				}

				if(!pat.servedFirstDrink){
					//First patron to be served or previous patron order has been completed
					//pat. 
					pat.waitEnd = System.currentTimeMillis(); //Time it took to be served.
					System.out.println("*****Barman handling first Order for Patron " + nextOrder.getPatronID());
					pat.servedFirstDrink = true;
					throughPut++;
				}

				System.out.println("---Barman preparing order for patron "+ nextOrder.toString());
				sleep(nextOrder.getExecutionTime()); //processing order
				System.out.println("---Barman has made order for patron "+ nextOrder.toString());

				if (!firstDrink){
					pat.respEnd = System.currentTimeMillis();
				}
				nextOrder.orderDone();
			}
				
		} catch (InterruptedException e1) {
			lastTime = System.currentTimeMillis();
			System.out.println(String.format("Patrons %d,Total Time taken %d",throughPut,lastTime - firstTime));
			throughPut = ((throughPut * 1000*60*60)/(lastTime - firstTime));
			System.out.println("---Barman is packing up---");
			/*drinkServed.forEach((key,value)->{				
				try{
				SchedulingSimulation.writer.write(String.format("%s,%d\n,",key,value));}
				catch(IOException e){}
			}); */
		}
	}
}


