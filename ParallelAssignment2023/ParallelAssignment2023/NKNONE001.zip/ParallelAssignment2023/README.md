There are 2 repositories:
    1.Master
    2.pyVerse
pyVerse is resposnsible for generating graphs for analysis(report purposes)
When running main file for this repo, which is dataCleaner, you are prompted to enter the initial grid size, which is the value of the row and column of the grid size, then followed by the amount of times the program will execute the java programs.

Then the java programs write onto the files the resulting data. Then the data is then analyse to generate graphs.

Master repo contains the main part of the assignment.
