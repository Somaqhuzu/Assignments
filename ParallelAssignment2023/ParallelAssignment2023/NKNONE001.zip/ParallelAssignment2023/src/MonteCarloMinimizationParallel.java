import java.util.concurrent.ForkJoinPool;
import java.io.*;



public class MonteCarloMinimizationParallel{
	static long startTime,endTime;
    //This class will initialize and instantiate every data needed for class {TerrainArea,SearchParallel}
	private static void tick() {
		startTime = System.currentTimeMillis();
	}

	private static void tock() {
		endTime = System.currentTimeMillis();
	}
    public static void main(String [] args) throws IOException{
        ForkJoinPool pool = new ForkJoinPool();

		/*Speed= totalSearches/timeTook for all searches
		 *Percent = numberofSearches/totalSearches
		 * each line on file speed will be in this format -->  {Time,Evaluated(points),Visited(points),Search_Speed,Num_Searches}
		*/
		File speed = null;
		FileWriter speedWriter=null;
		PrintWriter speedPrinter=null;		
		
		try{
			speed = new File("ParallelSpeed.csv");
			if (!speed.exists()){
				speedWriter = new FileWriter(speed);
				speedPrinter = new PrintWriter(speedWriter);
				speedPrinter.print("Time,Evaluated,Visited,Search_Speed,Num_Searches");
			}
			else{
				speedWriter = new FileWriter(speed,true);
				speedPrinter = new PrintWriter(speedWriter);
			}
		}
		catch(IOException e){System.exit(0);}

        int rows, columns; //grid size
    	double xmin, xmax, ymin, ymax; //x and y terrain limits
   		double searches_density;	// Density - number of Monte Carlo  searches per grid position - usually less than 1!

     	int num_searches;		// Number of searches
    	if (args.length!=8) {  
    		/*System.out.println("Incorrect number of command line arguments provided.");   	
    		System.exit(0);*/
			rows=6;columns=6;xmin=120;xmax=21;ymin=12;ymax=-120;searches_density=6;
			SearchParallel.SEQUENTIAL_CUT_OFF = 1000;
    	}
    	/* Read argument values */
		else{
    	rows =Integer.parseInt( args[0] );
    	columns= Integer.parseInt( args[1] );
    	xmin = Double.parseDouble(args[2] );
    	xmax = Double.parseDouble(args[3] );
    	ymin = Double.parseDouble(args[4] );
    	ymax = Double.parseDouble(args[5] );
    	searches_density = Double.parseDouble(args[6] );
		SearchParallel.SEQUENTIAL_CUT_OFF= Integer.parseInt(args[7]);}

        SearchParallel.terrain = new TerrainArea(rows, columns, xmin,xmax,ymin,ymax);
    	num_searches = (int)( rows * columns * searches_density );
    	SearchParallel.arr= new SearchParallel [num_searches];
    	for (int i=0;i<num_searches;i++) 
    		SearchParallel.arr[i]=new SearchParallel(i);
		SearchParallel search = new SearchParallel(0,num_searches);

		tick();
		pool.invoke(search);
		tock();
		String time = endTime - startTime +"";
		int eval = SearchParallel.terrain.getGrid_points_evaluated();
		int vis = SearchParallel.terrain.getGrid_points_visited();
		double sprint = num_searches/(endTime-startTime);

		speedPrinter.printf("\n%s,%s,%s,%s,%s",time,eval,vis,sprint,num_searches); //Writing to the data file for analysis
		speedPrinter.close();    
    }
}
